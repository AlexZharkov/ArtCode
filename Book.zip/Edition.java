package InterfaceAndAbstractClass;

/**
 * Created by Андрей on 26.10.2016.
 */
public interface Edition {

    void edition();
    void editionData();
    void author();


}
